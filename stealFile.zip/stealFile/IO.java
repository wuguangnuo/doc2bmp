import java.io.*;
import java.time.LocalDateTime;
import java.util.Scanner;

/**
 * IO流处理
 */
public class IO {
    private static Config config;
    private static long timestmp = System.currentTimeMillis();
    private static final String fn = LocalDateTime.now().toString()
            .replaceAll(":", "").replaceAll("-", "").split("[.]")[0];

    public IO getInstance(Config c) {
        config = c;
        return new IO();
    }

    /**
     * 读取文档文件
     *
     * @param path 文件路径
     * @return byte[]
     */
    public byte[] readDoc(String path) {
        try {
            FileInputStream fis = new FileInputStream(path);
            BufferedInputStream bis = new BufferedInputStream(fis);
            byte[] data = new byte[bis.available()];
            bis.read(data);
            print("ReadDoc Complete");
            bis.close();
            fis.close();
            return data;
        } catch (FileNotFoundException e) {
            print("读取文件错误");
        } catch (IOException e) {
            print("IO异常");
        }
        return null;
    }

    /**
     * 读取BMP文件(BMP24位)
     *
     * @param path 文件路径
     * @return byte[]
     */
    public byte[] readBmp(String path) {
        try {
            FileInputStream fis = new FileInputStream(path);
            BufferedInputStream bis = new BufferedInputStream(fis);

            bis.skip(18L);
            byte[] b = new byte[4];
            bis.read(b);
            byte[] b2 = new byte[4];
            bis.read(b2);

            int width = byte2Int(b), heigth = byte2Int(b2);
            byte[] date = new byte[heigth * width * 3 - config.getComplementary()];
            print("Height：" + heigth + "，Width：" + width);

            bis.skip(28L);
            bis.read(date);
            print("ReadBmp Complete");
            bis.close();
            fis.close();
            return date;
        } catch (FileNotFoundException e) {
            print("读取文件错误");
        } catch (IOException e) {
            print("IO异常");
        }
        return null;
    }

    /**
     * 写入文档文件
     *
     * @param data   byte[]
     * @param suffix 后缀
     */
    public void writeDoc(byte[] data, String suffix) {
//        data = reDeflection(data);

        String fileName = getFileName(suffix);
        File file = new File(fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            bos.write(data, 0, data.length);
            print("WriteDoc Success");
            bos.close();
            fos.close();
        } catch (FileNotFoundException e) {
            print("创建文件失败");
        } catch (IOException e) {
            print("IO异常");
        }
    }

    /**
     * 写入BMP文件
     *
     * @param data byte[]
     */
    public void writeBmp(byte[] data) {
        data = doDeflection(data);

        int width = config.getWidth();
        int height = data.length % (3 * width) == 0 ? data.length / 3 / width : data.length / 3 / width + 1;
//        print("补位大小：" + (width * height * 3 - data.length) + "Byte");

        String fileName = getFileName("bmp");
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            BufferedOutputStream bos = new BufferedOutputStream(fos);

            // 给文件头的变量赋值
            bos.write(new byte[]{0x42, 0x4d}, 0, 2);
            bos.write(int2Byte(54 + width * height * 3), 0, 4);
            bos.write(new byte[]{0, 0, 0, 0, 0x36, 0, 0, 0, 0x28, 0, 0, 0}, 0, 12);
            bos.write(int2Byte(width), 0, 4);
            bos.write(int2Byte(height), 0, 4);
            bos.write(new byte[]{1, 0, 0x18, 0, 0, 0, 0, 0}, 0, 8);
            bos.write(int2Byte(width * height), 0, 4);
            bos.write(new byte[16], 0, 0x10);

            bos.write(data);
            bos.write(new byte[width * height * 3 - data.length]);

            bos.close();
            fos.close();
            print("WriteBmp Success");
        } catch (FileNotFoundException e) {
            print("创建文件失败");
        } catch (IOException e) {
            print("IO异常");
        }
    }

    /**
     * 格式化打印
     *
     * @param x 打印的内容
     */
    public void print(String x) {
        long n = System.currentTimeMillis();
        String msg = "--- " + x + (config.isDebug() ? " " + (n - timestmp) + "ms" : "") + " ;";
        System.out.println(msg);

        if (config.isDebug()) {
            String logFileName = config.getDefaultPath() + "\\" + config.getLogFileName();
            try {
                File file = new File(logFileName);
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedWriter bw = new BufferedWriter(
                        new OutputStreamWriter(
                                new FileOutputStream(logFileName, true)));
                bw.write(LocalDateTime.now().toString().replaceAll("T", " ").split("[.]")[0] +
                        " " + msg + "\r\n");
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        timestmp = n;
    }

    /**
     * 获取输入
     *
     * @param x
     * @return
     */
    public String scanner(String x) {
        System.out.println(x);
        String input = new Scanner(System.in).nextLine();
        print(x + input);
        return input;
    }

    /**
     * 增加误差(白移)
     *
     * @param data byte[]
     * @return byte[]
     */
    private static byte[] doDeflection(byte[] data) {
        // i, j, a 计数器;
        int i, j, a;
        // x 误差等级, b 彩色模式调整
        int x = config.getDeflection(), b = config.isColorful() ? 1 : 3;
        int m = pow(2, x), n = pow(2, 3 - x);
        byte[] res = new byte[data.length * m * b];
        for (i = 0; i < data.length; i++) {
            for (j = 0; j < m * b; j++) {
                a = (data[i] & getHelp(j / b)) >> (8 - n - (j / b * n));
                res[b * m * i + j] = a == 0 ? 0 : (byte) ((pow(2, (8 - n))) * (a + 1) - 1);
            }
        }
        return res;
    }

    /**
     * 辅助函数
     *
     * @param y int
     * @return int
     */
    private static int getHelp(int y) {
        int r, c, i, j, x = config.getDeflection();
        int[] base = new int[]{128, 64, 32, 16, 8, 4, 2, 1}, arr = new int[pow(2, x)];

        for (i = 0; i < pow(2, x); i++) {
            r = 0;
            // 每次 c 个，第 c*i 个开始，c*i+c 个结束
            c = pow(2, 3 - x);
            for (j = i * c; j < i * c + c; j++) {
                r += base[j];
            }
            arr[i] = r;
        }
        return arr[y];
    }

    /**
     * 减少误差
     *
     * @param data byte[]
     * @return byte[]
     */
    public static byte[] reDeflection(byte[] data) {
        if (!config.isColorful()) {
            data = wb2color(data);
        }

        int i, j, r, a, x = config.getDeflection(), l = data.length >> x;
        byte[] res = new byte[l];
        for (i = 0; i < l; i++) {
            r = 0;
            for (j = 0; j < pow(2, x); j++) {
                a = checkDeflection(data[i * pow(2, x) + j]);
                r += ((a + (a < 0 ? 0x100 : 0)) >> j * pow(2, 3 - x)) & getHelp(j);
            }
            res[i] = (byte) r;
        }
        return res;
    }

    /**
     * 黑白长度除三
     *
     * @param data byte[]
     * @return byte[]
     */
    private static byte[] wb2color(byte[] data) {
        byte[] res = new byte[data.length / 3];
        for (int i = 0; i < data.length; i += 3) {
            if (data[i] == data[i + 1] && data[i] == data[i + 2]) {
                res[i / 3] = data[i];
            } else {
                if (data[i] == data[i + 1] || data[i] == data[i + 2]) {
                    res[i / 3] = data[i];
                } else if (data[i + 1] == data[i + 2]) {
                    res[i / 3] = data[i + 1];
                } else {
                    res[i / 3] = (byte) ((data[i] + data[i + 1] + data[i + 2]) / 3);
                }
            }
        }
        return res;
    }

    /**
     * 勘误
     *
     * @param a 勘误前
     * @return 勘误后
     */
    private static int checkDeflection(int a) {
        if (config.getDeflection() == 0) {
            return a;
        }
        int t = pow(2, (8 - pow(2, 3 - config.getDeflection())));
        if (a >= 0) {
            a /= t;
            if (a == 0) {
                return 0;
            } else {
                return a * t + t - 1;
            }
        } else {
            a /= t;
            if (a == 0) {
                return -1;
            } else {
                return a * t - 1;
            }
        }
    }

    /**
     * 生成文件名
     *
     * @param suffix 文件后缀
     * @return FilePath
     */
    private static String getFileName(String suffix) {
        String cf = config.getDefaultPath() + File.separator + fn;
        File f = new File(cf);
        if (!f.exists()) {
            f.mkdir();
        }
        return cf + File.separator + System.currentTimeMillis() + "." + suffix;
    }

    /**
     * 将四个byte拼接成一个int
     *
     * @param b byte[4]
     * @return int
     */
    private static int byte2Int(byte[] b) {
        return (b[3] & 0xff) << 24 |
                (b[2] & 0xff) << 16 |
                (b[1] & 0xff) << 8 |
                (b[0] & 0xff);
    }

    /**
     * int 转 byte[4]
     *
     * @param data int
     * @return byte[4]
     */
    private static byte[] int2Byte(int data) {
        return new byte[]{(byte) (((data) << 24) >> 24),
                (byte) (((data) << 16) >> 24),
                (byte) (((data) << 8) >> 24),
                (byte) ((data) >> 24)};
    }

    /**
     * 乘方 Math.pow(a,b)
     *
     * @param a the base.
     * @param b the exponent.
     * @return the value {@code a}<sup>{@code b}</sup>.
     */
    public static int pow(int a, int b) {
        if (b < 0) {
            return 1;
        }
        if (a == 2) {
            return 1 << b;
        }
        int i, r = 1;
        for (i = 0; i < b; i++) {
            r *= a;
        }
        return r;
    }
}
