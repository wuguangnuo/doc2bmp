Steal File.

author WuGuangNuo

内:
xxx.zip -> (config) -> 动图

外:
定时截图 -> (config) -> 恢复