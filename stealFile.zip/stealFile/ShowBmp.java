import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

/**
 * 内部使用
 * 显示图片
 */
public class ShowBmp extends JFrame {
    private JLabel label;
    private int t = -1;
    private static Config config = new Config();
    private static IO io = new IO().getInstance(config);

    public static void main(String[] args) {
        String input = io.scanner("输入文件夹名：");

        java.util.List<String> fileNames = new ArrayList<>();
        File v1 = new File(config.getDefaultPath() + File.separator + input);

        for (File f : Objects.requireNonNull(v1.listFiles())) {
            if (f.getName().endsWith(".bmp")) {
                fileNames.add(f.getPath());
            }
        }
        String[] v2 = new String[fileNames.size()];
        for (int i = 0; i < v2.length; i++) {
            v2[i] = fileNames.get(i);
        }
        Arrays.sort(v2);

        new ShowBmp(Arrays.asList(v2)).setVisible(true);
    }

    private ShowBmp(java.util.List<String> bmpFiles) {
        super("ShowBmp");
        Image image = null;

        try {
            image = ImageIO.read(new File(bmpFiles.get(0)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        label = new JLabel(new ImageIcon(image));
        this.add(label);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(config.getWidth() + 100, config.getWidth() + 100);
        getContentPane().setBackground(Color.green);
        getContentPane().setVisible(true);

        Timer timer = new Timer(config.getDelay(), e -> {
            if (t >= bmpFiles.size()) {
                io.print("END ---");
                System.exit(1);
            }
            if (t >= 0) {
                io.print("第" + (t + 1) + "张: " + bmpFiles.get(t).substring(config.getDefaultPath().length()));
                try {
                    label.setIcon(new ImageIcon(ImageIO.read(new File(bmpFiles.get(t)))));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            } else {
                io.print("等待..");
            }
            t++;
        });
        timer.start();
    }
}
