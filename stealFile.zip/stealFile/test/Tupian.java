package test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tupian extends JFrame implements ActionListener {
    JLabel jl = new JLabel("图片");
    JMenuBar jmb = new JMenuBar();
    JMenu jm = new JMenu("文件");
    JMenuItem jmi = new JMenuItem("选择图片");
    JPanel jp = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JFileChooser chooser = new JFileChooser();

    public Tupian() {
        super("浏览图片");
        jmb.add(jm);
        jm.add(jmi);
        jp.add(jl);
        jmi.addActionListener(this);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.add(jmb, BorderLayout.NORTH);
        this.add(jp, BorderLayout.CENTER);
        this.setSize(800, 600);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int i = chooser.showOpenDialog(this);
        if (i == JFileChooser.APPROVE_OPTION) {
            Image image = new ImageIcon(chooser.getSelectedFile().getPath()).getImage();
            image = image.getScaledInstance(400, 400, Image.SCALE_DEFAULT);
            jl.setIcon(new ImageIcon(image));
            jl.setText("");
        }
        if (i == JFileChooser.CANCEL_OPTION) {
            return;
        }
    }

    public static void main(String[] args) {
        new Tupian();
    }
}
