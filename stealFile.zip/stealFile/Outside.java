import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * 外部使用
 * 将图片转文件
 */
public class Outside {
    private static Config config = new Config();
    private static IO io = new IO().getInstance(config);

    public static void main(String[] args) {
        String input = io.scanner("输入文件夹名：");
        int length = Integer.parseInt(io.scanner("输入文件大小(data.length)："));

        wash(config.getDefaultPath() + File.separator + input);

        java.util.List<String> bmpFiles = new ArrayList<>();
        for (File f : Objects.requireNonNull(new File(config.getDefaultPath() + File.separator + input).listFiles())) {
            if (f.getName().endsWith(".bmp")) {
                bmpFiles.add(f.getPath());
            }
        }

        byte[] data = new byte[length];
        for (int i = 0; i < bmpFiles.size(); i++) {
            String path = bmpFiles.get(i);
            byte[] dataTrans = io.reDeflection(io.readBmp(path));
            for (int j = 0; j < dataTrans.length; j++) {
                if (dataTrans.length * i + j >= length) {
                    break;
                }
                data[i * dataTrans.length + j] = dataTrans[j];
            }
        }
        io.writeDoc(data, config.getSuffix());

        io.print("END ---");
    }

    /**
     * 清洗数据
     *
     * @param path
     */
    private static void wash(String path) {
        io.print("开始清洗数据");
        List<String> names = new ArrayList<>();
        for (File f : Objects.requireNonNull(new File(path).listFiles())) {
            if (f.getName().endsWith(".bmp")) {
                names.add(f.getPath());
            }
        }
        String[] v2 = new String[names.size()];
        for (int i = 0; i < v2.length; i++) {
            v2[i] = names.get(i);
        }
        Arrays.sort(v2);
        names.clear();
        names = Arrays.asList(v2);

        for (int i = 0; i < names.size() - 1; i++) {
            io.print("清洗第" + (i + 1) + "个");
            diff(names.get(i), names.get(i + 1));
        }


        io.print("第二次清洗数据");
        names = new ArrayList<>();
        for (File f : Objects.requireNonNull(new File(path).listFiles())) {
            if (f.getName().endsWith(".bmp")) {
                names.add(f.getPath());
            }
        }
        for (int i = 0; i < names.size(); i++) {
            io.print("清洗第" + (i + 1) + "个");
            checkBmp(names.get(i));
        }
    }

    /**
     * diff and delete
     *
     * @param n1
     * @param n2
     */
    private static void diff(String n1, String n2) {
        byte[] d1 = new byte[0], d2 = new byte[0];

        try {
            FileInputStream fis = new FileInputStream(n1);
            BufferedInputStream bis = new BufferedInputStream(fis);
            d1 = new byte[bis.available()];
            bis.read(d1);
            bis.close();

            fis = new FileInputStream(n2);
            bis = new BufferedInputStream(fis);
            d2 = new byte[bis.available()];
            bis.read(d2);
            bis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < d1.length; i++) {
            if (d1[i] != d2[i]) {
                return;
            }
        }

        io.print("删除:" + n1);
        File f = new File(n1);
        f.delete();
    }

    /**
     * 删除多余文件
     *
     * @param n
     */
    private static void checkBmp(String n) {
        byte[] d = new byte[0];
        try {
            FileInputStream fis = new FileInputStream(n);
            BufferedInputStream bis = new BufferedInputStream(fis);
            d = new byte[bis.available()];
            bis.read(d);
            bis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int randomNum = 1000; // 1000个随机样本
        int[] randoms = new int[randomNum];
        for (int i = 0; i < randomNum; i++) {
            randoms[i] = (int) (Math.random() * 1024 * 1024 * 3) + 54;
        }
        for (int i = 0; i < randomNum; i++) {
            if (!accept(d[randoms[i]])) {
                io.print("删除:" + n);
                File f = new File(n);
                f.delete();
                return;
            }
        }
    }

    private static boolean accept(byte x) {
        int a = Math.abs(x + 65);
        int b = Math.abs(x + 1);
        int c = Math.abs(x - 127);
        int d = Math.abs(x);
        int y = Math.min(Math.min(a, b), Math.min(c, d));
        return y == 0; // 最严格
    }
}
