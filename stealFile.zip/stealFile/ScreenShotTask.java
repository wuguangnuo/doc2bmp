import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 外部使用
 * 定时截图
 */
public class ScreenShotTask {
    private static Config config = new Config();
    private static IO io = new IO().getInstance(config);

    private static int num = 0;
    private static int maxNum = 2000;

    private static int x = 50;
    private static int y = 61;
    private static int width = config.getWidth();
    private static int height = width;
    private static String suffix = "bmp";
    private static int period = config.getDelay() / 3;
    private static String basePath = config.getDefaultPath() + File.separator + System.currentTimeMillis();

    public static void main(String[] args) {
        File file = new File(basePath);
        if (!file.exists()) {
            file.mkdir();
        }

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                screenShot();
                if (num >= maxNum) {
                    System.exit(1);
                }
            }
        };

        new Timer().scheduleAtFixedRate(task, 0, period);
    }

    private static void screenShot() {
        num++;
        String path = basePath + File.separator + getNum(num) + "." + suffix;

        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        try {
            ImageIO.write(new Robot()
                            .createScreenCapture(new Rectangle(0, 0, d.width, d.height))
                            .getSubimage(x, y, width, height),
                    suffix, new File(path)
            );
        } catch (IOException | AWTException e) {
            e.printStackTrace();
        }
        io.print("截图:第" + num + "张 " + path.substring(config.getDefaultPath().length()));
    }

    private static String getNum(int x) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6 - (x + "").length(); i++) {
            sb.append(0);
        }
        sb.append(x);
        return sb.toString();
    }
}