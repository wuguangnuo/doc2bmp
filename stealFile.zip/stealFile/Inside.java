import java.io.File;

/**
 * 内部使用
 * 将文件转成图片
 */
public class Inside {
    public static void main(String[] args) {
        Config config = new Config();
        IO io = new IO().getInstance(config);

        String input = io.scanner("输入文件名称：");
        config.setDocFileName(input);

        byte[] data = io.readDoc(config.getDefaultPath() + File.separator + config.getDocFileName());
        int pageSize = config.getWidth() * config.getWidth() / io.pow(2, config.getDeflection());
        byte[] dataTrans;
        int pageNum = (data.length / pageSize) + (data.length % pageSize == 0 ? 0 : 1);
        io.print("[data.length = " + data.length + ", pageNum = " + pageNum + "]");
        for (int i = 0; i < pageNum; i++) {
            dataTrans = new byte[pageSize];
            for (int j = 0; j < pageSize; j++) {
                if (i * pageSize + j >= data.length) {
                    break;
                }
                dataTrans[j] = data[i * pageSize + j];
            }
            io.writeBmp(dataTrans);
        }

        io.print("END ---");
    }
}
